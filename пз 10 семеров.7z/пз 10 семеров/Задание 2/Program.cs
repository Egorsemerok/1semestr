﻿using System;

namespace ПЗ_10_з2
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int max = int.MinValue; 
            int position = 0; 
            int currentPosition = 0; 

            do
            {
                Console.Write("Введите целое число (0 для завершения): ");
                number = Convert.ToInt32(Console.ReadLine());

                if (number != 0) 
                {
                    currentPosition++; 

                    if (number > max) 
                    {
                        max = number; 
                        position = currentPosition; 
                    }
                }

            } while (number != 0); 

            if (max == int.MinValue)
            {
                Console.WriteLine("Последовательность была пустой.");
            }
            else
            {
                Console.WriteLine($"Максимальное число в последовательности: {max}");
                Console.WriteLine($"Порядковый номер максимального числа: {position}");
            }

            Console.ReadKey();
        }
    }
}