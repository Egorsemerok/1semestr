﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Program_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            System.Console.WriteLine("Введите Ваше имя: ");
            name = System.Console.ReadLine();
            System.Console.WriteLine("Приветствую вас," + name + "!");
        }
    }
}
